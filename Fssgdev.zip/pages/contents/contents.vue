<template>
	<view class="content">
		<view class="HeadTitle">
			<view class="LogoView">
				<image class="LOGO" src="../../static/img/loginLOGO.png"></image>
				<view><text>{{systeam}}</text></view>
			</view>
		</view>
		<view class="HeadContente">
			<view v-for="(row,i) in listTemp" :key="row.id" class="v_row">
				<view :id="j" v-for="(cell,key,j) in row" :key="cell.id" class="v_row_block">
					<view class="v_col">
						<view class="v_row_v_img">
						<img :src="cell.url"></img>
						</view>
						<view :id="'T_'+(i*3+j)">{{cell.name}}</view>
					</view>
				</view>
			</view>  
		</view>
	</view>
</template>

<script>
	import Global from '../../store/Global.js';
	export default {
		components: {
		},
		data() {
			return {
				systeam: Global.sysname,
				list:[
					{"url":'../../static/img/conZL.png',"name":'我的资料'},
					{"url":'../../static/img/conRC.png',"name":'日程'},
					{"url":'../../static/img/conZX.png',"name":'信息中心'},
					{"url":'../../static/img/conSP.png',"name":'审批'},
					{"url":'../../static/img/conTX.png',"name":'提醒'},
					{"url":'../../static/img/conGZ.png',"name":'工作'},
					{"url":'../../static/img/conYJ.png',"name":'邮件'},
					{"url":'../../static/img/conFJ.png',"name":'附件'},
					{"url":'../../static/img/conQT.png',"name":'其他'},
				]
			};
		},
		created:function () {
			//this.getContents();
		},
		computed: {
			//计算函数
			listTemp: function () { //数据分组
				var list = this.list;
				var arrTemp = [];
				var index = 0;
				var sectionCount = 3; //一行显示多少个
				for (var i = 0; i < list.length; i++) {
					index = parseInt(i / sectionCount); //取余数
					if (arrTemp.length <= index) { //每隔 sectionCount 个数据添加一行
						arrTemp.push([]);
					}
					arrTemp[index].push(list[i]); //每行添加 sectionCount 个数据
				}
				return arrTemp;
			}
		},
		methods: {
			getContents() {//获取目录面板数据
				var self = this;
				uni.showLoading({
					title: '正在获取'
				});
				const result = service.getContents(1, 1, function() {
// 					uni.showToast({
// 						icon: 'none',
// 						title: '登录成功'
// 					});
				});
			},
		}
	};
</script>

<style>
	.v_row_v_img {
		width: 100%;
		height: 80upx;
		margin-top: 10upx;
		justify-content: center;
		align-items: centerc;
	}
	.v_col img {
		width: 80upx;
		height: 80upx;
	}
	.v_row_block {
		background-color:#FFFFFF;
		width:160upx;
		height:160upx;
		display:flex;
		justify-content: center;
		align-items: center;
		border-radius:8%;
		box-shadow:0px 5px 30rpx #2D97F1;
		border:1rpx solid #FFFFFF;
	}
	.v_row {
		color:black;
		display: flex;
		justify-content:space-between;
		padding: 20upx;
	}
	.v_col {
		width: 120upx;
		text-align:center;
	}
	.t_view {
		display: flex;
		width: 100%;
		justify-content: center;
		align-items: center;
		align-items: ;
	}
	.content {
		height: 100vh;
		overflow: hidden;
		background: linear-gradient(#1A9EFF, #80C9FC); /* 标准的语法 */
		padding: 0px;
	}
	.LogoView text{
		color: #FFFFFF;
		font-size: 40upx;
		letter-spacing:5px;
	}
	.LogoView {
		text-align: center;
	}
	.LOGO {
		width: 250upx;
		height: 220upx;
	}
	.HeadTitle {
		position: relative;
	}
	.HeadContente {
		margin-top: 20upx;
		padding: 65rpx;
	}
</style>
