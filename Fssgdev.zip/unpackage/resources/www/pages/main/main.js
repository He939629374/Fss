
      !(function(){
        var uniAppViewReadyCallback = function(){
          setCssToHead([".",[1],"hello { display: -webkit-box; display: -webkit-flex; display: -ms-flexbox; display: flex; -webkit-box-flex: 1; -webkit-flex: 1; -ms-flex: 1; flex: 1; -webkit-box-orient: vertical; -webkit-box-direction: normal; -webkit-flex-direction: column; -ms-flex-direction: column; flex-direction: column; }\n.",[1],"title { color: #8f8f94; margin-top: ",[0,50],"; }\n.",[1],"ul { font-size: ",[0,30],"; color: #8f8f94; margin-top: ",[0,50],"; }\n.",[1],"ul\x3ewx-view { line-height: ",[0,50],"; }\n",],undefined,{path:"./pages/main/main.wxss"})();
document.dispatchEvent(new CustomEvent("generateFuncReady", { detail: { generateFunc: $gwx('./pages/main/main.wxml') } }));
        }
        if(window.__uniAppViewReady__){
          uniAppViewReadyCallback()
        }else{
          document.addEventListener('uniAppViewReady',uniAppViewReadyCallback)
        }
      })();
      